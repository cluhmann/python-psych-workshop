import datetime
import glob
import csv
from psychopy import core
from psychopy import visual
from psychopy import gui
from psychopy import misc
from psychopy import event


def log(w, t):
    '''Log an individual trial's data to specificed text file'''

    # spit out to screen first
    print t

    # now log to the log file
    w.writerow(t)


def wait_spacebar():
    '''wait for a spacebar press, then return'''
    # clear keyboard buffer
    event.getKeys()
    # wait for response
    response = 0
    while response == 0:
        # continually check for keyboard input
        for key in event.getKeys():
            # if input received, check to see if it was a spacebar
            if key in ['space']:
                response = 1


def get_response(allowed_keys, timer, timeout):
    '''wait for a spacebar press, then return'''
    # clear the keyboard buffer
    event.clearEvents()

    # wait for either a response or for timeout
    while timer.getTime() < timeout:

        for key in event.getKeys():

            # only accept the specified keys
            if key in allowed_keys:

                # return the response and the timer value (e.g., RT)
                return key, timer.getTime()

    return '', 0


#--------------------------------------------------EXP CONSTANTS
winSize= [800.0, 800.0]
bgColor = [0, 0, 0]
textColor = [-1, -1, -1]

#--------------------------------------------------GET USER INFO
dlg = gui.Dlg(title="Shooter task")
dlg.addText('')
dlg.addField('Subject Number:', 99)
dlg.addText('')
dlg.addField('Subject Age:', 99)
dlg.addText('')
dlg.show()

if not dlg.OK:
    print 'user cancelled'
    core.quit()

#--------------------------------------------------SUB INFO & LOG FILE
sub_number = int(dlg.data[0])
age = dlg.data[1]
log_file = open('shooter-' + str(sub_number) + '.csv', 'a')

#--------------------------------------------------INITIALISE STIMULI

# create a window to draw in
exp_window=visual.Window(winSize, fullscr=0, bitsMode=None, units='norm',\
                    winType='pyglet', color=bgColor, colorSpace='rgb')

# set up some locations to be used later
locImg = [0, 0]
locText = [0, -0.3]

# create the 'spacebar to next trial' text
continue_stim = visual.TextStim(exp_window, pos = [0, 0], text = 'Press the spacebar to continue', color = textColor, colorSpace = 'rgb', height = .1)

# set up a timer
timer = core.Clock()


#--------------------------------------------------INITIALISE MAIN DATA STRUCTURE

# import file names of images
file_names = glob.glob('./images/*.jpg')

# this will contain all trial information
# could use a pandas dataframe for this instead
exp_data = []

# how many repititions per image do we want?
nReps = 1

# loop through the repetitions, note that repetitions will not be blocked
for rep in range(nReps):
    # loop through the images
    for file_name in file_names:
        # create a new trial structure
        trial = {}

        # get subject info into each trial's info
        trial['subject'] = sub_number
        trial['age'] = age

        # assign image to this trial
        trial['image'] = file_name

        # assign the appropriate condition information to this trial
        if file_name[11] == 'b':
            trial['target'] = 'black'
        else:
            trial['target'] = 'white'

        if file_name[12] == 'a':
            trial['object'] = 'gun'
        else:
            trial['object'] = 'nogun'

        # populate the new trial structure with 'blank' information
        trial['rt'] = -77
        trial['response'] = ''
        trial['time'] = -77

        # add the new trial to the data structure
        exp_data.append(trial)

# randomize the order of the trials in the data structure
exp_data = misc.shuffleArray(exp_data)

# create a DictionaryWriter object (part of the csv package) to log trial info
# supply log file name and fields we wish to log
log_writer = csv.DictWriter(log_file, fieldnames=exp_data[0].keys())

# insert headers (variable names) at the top of the log file
log_writer.writeheader()


#--------------------------------------------------RUN THE TASK

# draw our instructions
message = visual.TextStim(exp_window, text='Howdy!\n\nPress the spacebar to begin.',\
                          color=textColor, colorSpace='rgb', height=.1, pos=(0,0))
message.draw()
exp_window.flip()

# wait for a spacebar to begin
wait_spacebar()

# clear the screen once we've gotten a spacebar
exp_window.flip()

# wait a couple seconds
core.wait(2)

# run through the trials in our data structure
for trial in exp_data:

    # clear the screen
    exp_window.flip()

    # note what time this trial began
    trial['time'] = datetime.datetime.now()

    # figure out which trial type we are going to show this trial
    image = visual.PatchStim(exp_window, tex=trial['image'], pos=locImg, size=[(4/3.) * 1.5, 1.5], units='norm')

    # draw the just-created image
    image.draw()

    # now draw everything to the screen
    exp_window.flip()
    # and immediately (re)start the timer
    timer.reset()

    # collect a response
    response, rt = get_response(['1', '2', 'escape'], timer, 3)

    # allow experimenter to bail with an escape key press
    if response == 'escape':
        log_file.close()
        exp_window.close()
        core.quit()

    exp_window.flip()
    core.wait(1)

    # 'grade' the response
    if (trial['object'] == 'gun') and (response == '1'):
        trial['response'] = 'correct'
    elif (trial['object'] == 'nogun') and (response == '0'):
        trial['response'] = 'correct'
    else:
        trial['response'] = 'incorrect'
    # save reaction time
    trial['rt'] = rt

    # log data for this trial
    log(log_writer, trial)

    # ask for a spacebar press
    continue_stim.draw()
    exp_window.flip()

    # wait for a spacebar press
    wait_spacebar()

    # clear the screen and wait a moment before moving on (ITI)
    exp_window.flip()
    core.wait(1)


#--------------------------------------------------FINISH UP

# let the subject know they're done
message = visual.TextStim(exp_window, pos=(0,0), text='Done!\n\nPlease let the experimenter know you are done.',\
            color=textColor, colorSpace='rgb')
message.draw()
exp_window.flip()

# wait a moment
core.wait(2)

# finish up, clean up
# close the log file
log_file.close()
# close the experiment window
exp_window.close()
# exit nicely
core.quit()